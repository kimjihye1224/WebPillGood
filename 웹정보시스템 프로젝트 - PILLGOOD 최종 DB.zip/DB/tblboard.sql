-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        5.7.22-log - MySQL Community Server (GPL)
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- pillgood 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `pillgood` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pillgood`;

-- 테이블 pillgood.tblboard 구조 내보내기
CREATE TABLE IF NOT EXISTS `tblboard` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `content` text,
  `pos` smallint(7) unsigned DEFAULT NULL,
  `ref` smallint(7) DEFAULT NULL,
  `depth` smallint(7) unsigned DEFAULT NULL,
  `regdate` varchar(20) DEFAULT NULL,
  `pass` varchar(15) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `count` smallint(7) unsigned DEFAULT NULL,
  `filename` varchar(500) DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `boardType` int(3) DEFAULT NULL,
  `grade` int(3) unsigned zerofill DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `FK_tblboard_userinfo` (`nickname`),
  CONSTRAINT `FK_tblboard_userinfo` FOREIGN KEY (`nickname`) REFERENCES `userinfo` (`nickname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- 테이블 데이터 pillgood.tblboard:~30 rows (대략적) 내보내기
/*!40000 ALTER TABLE `tblboard` DISABLE KEYS */;
INSERT INTO `tblboard` (`num`, `nickname`, `subject`, `content`, `pos`, `ref`, `depth`, `regdate`, `pass`, `ip`, `count`, `filename`, `filesize`, `boardType`, `grade`) VALUES
	(1, '라일락', '비카린엠장용정', '가끔 변비 심할 때 먹고 있어요. ', 0, 0, 0, '2021-11-27 01:25:23', '1234', '0:0:0:0:0:0:0:1', 100, 'https://ifh.cc/g/jP1Dxu.png', 0, 0, 004),
	(2, '런온', 'counterpain Analgesic Balm', '브랜드: TAISHO, 성분: 유게놀', 0, 0, 0, '2018-12-25 19:05:00', '1234', '0:0:0:0:0:0:0:1', 36, 'https://ifh.cc/g/zYH8EE.jpg', 0, 1, 000),
	(3, '메인보컬', 'EVE', '브랜드: 에스에스, 성분: 이부프로펜', 0, 0, 0, '2021-11-27 01:25:23', '1234', '0:0:0:0:0:0:0:1', 16, 'https://ifh.cc/g/8XpMkf.jpg', 0, 1, 000),
	(4, '미미', '던던댄스', '유성이 비처럼 쏟아지는 하늘\r\n그 아래 너와 함께 춤추고 싶어\r\n색색의 옷들과 예쁜 액세서리 \r\n흐르는 저 음악이 내 맘을 설레게 하지\r\nI feel the disco rhythm in my body\r\n다른 아무것도 생각하진 마 ', 0, 0, 0, '2019-05-15 05:15:30', '1234', '0:0:0:0:0:0:0:1', 6, 'https://ifh.cc/g/vDjjf3.jpg', 0, 2, 000),
	(5, '블랙맘바', 'Don\'t you know', '두고 봐, 난 좀 savage\r\n너의 dirty 한 play, 더는 두고 볼 수 없어\r\n나를 무너뜨리고 싶은\r\n네 환각들이 점점 너를 구축할 이유가 돼', 0, 0, 0, '2018-12-25 19:05:00', '1234', '0:0:0:0:0:0:0:1', 15, 'https://ifh.cc/g/yMHkpI.jpg', 0, 2, 000),
	(6, '블루밍', '뭐해', '""뭐해"" 라는 두 글자에\r\n""네가 보고 싶어"" 나의 속마음을 담아 \r\n이모티콘 하나하나 속에\r\n달라지는 내 미묘한 심리를 알까 ', 0, 0, 0, '2021-11-27 01:25:23', '1234', '0:0:0:0:0:0:0:1', 6, 'https://ifh.cc/g/KoXahJ.jpg', 0, 2, 000),
	(7, '비니', '라베휴정20mg', '브랜드: 휴비스트제약, 성분: 라베프라졸나트륨', 0, 0, 0, '2020-10-20 02:25:40', '1234', '0:0:0:0:0:0:0:1', 11, 'https://ifh.cc/g/67yaPY.jpg', 0, 1, 000),
	(8, '쏘하이', '타이레놀정500밀리그람(아세트아미노펜)(수출명:TylenolExtraStrengthCaplets)', '두통 심할 때 먹어요. 효과가 빠르진 않아요.', 0, 0, 0, '2018-12-25 19:05:00', '1234', '0:0:0:0:0:0:0:1', 27, 'https://ifh.cc/g/x5cHJz.png', 0, 0, 003),
	(9, '서현', '대화이부프로펜정400밀리그램(수출명:UPRO400,IBUFEN)', '액상타입이 아니라 효과가 느려요.', 0, 0, 0, '2018-12-25 19:05:00', '1234', '0:0:0:0:0:0:0:1', 17, 'https://ifh.cc/g/gqPCsr.jpg', 0, 0, 003),
	(10, '슬기', '메가코정', '코감기 걸려서 샀어요. 패키지 그림이 귀여워요.', 0, 0, 0, '2017-01-01 00:01:01', '1234', '0:0:0:0:0:0:0:1', 11, 'https://ifh.cc/g/evfp6h.png', 0, 0, 004),
	(11, '써니', '터논연질캡슐', '브랜드: 종근당, 성분: 덱시부프로펜', 0, 0, 0, '2018-12-25 19:05:00', '1234', '0:0:0:0:0:0:0:1', 4, 'https://ifh.cc/g/pcqCVT.jpg', 0, 1, 000),
	(12, '아린', '훼스탈플러스정', '체했을 때 먹으면 속이 편해져요.', 0, 0, 0, '2017-01-01 00:01:01', '1234', '0:0:0:0:0:0:0:1', 5, 'https://ifh.cc/g/KaTkXy.jpg', 0, 0, 005),
	(13, '아이린', '안녕, 여름', '볼이 빨갛게 그을려도 괜찮아, 괜찮아\r\n태양이 가장 높은 바로 이 순간\r\n가까운 바닷가가 어디더라\r\n파도가 일렁이고 모래가 반짝이는\r\n언덕에 올라서도 좋을 거야\r\n수평선 멀리까지 내려다볼 수 있는', 0, 0, 0, '2018-12-25 19:05:00', '1234', '0:0:0:0:0:0:0:1', 4, 'https://ifh.cc/g/neWLOa.jpg', 0, 2, 000),
	(14, '에스파는나야', '둘이 될 순 없어', '에스파는 나야\r\n둘이 될 수 없어\r\nMonochrome to colors\r\n이건 evolution\r\n 위험한 장난을 쳐\r\n매혹적이지만 널\r\n부정할 밖에\r\n모든 걸 삼켜버릴, black mamba', 0, 0, 0, '2017-01-01 00:01:01', '1234', '0:0:0:0:0:0:0:1', 1, 'https://ifh.cc/g/O9EVg8.jpg', 0, 2, 000),
	(15, '마크', '탁센400이부프로펜연질캡슐', '생리통에 잘 들어요. 알약이 많이 크지 않아 삼키기 쉬워요.', 0, 0, 0, '2021-11-27 01:25:23', '1234', '0:0:0:0:0:0:0:1', 2, 'https://ifh.cc/g/e0hfsZ.jpg', 0, 0, 005),
	(16, '도영', '겔포스엠현탁액', '브랜드: 보령제약, 성분: 시메티콘', 0, 0, 0, '2020-10-20 02:25:40', '1234', '0:0:0:0:0:0:0:1', 9, 'https://ifh.cc/g/e19qeY.jpg', 0, 1, 000),
	(17, '디오', 'for life', 'This life has twist and turns\r\nBut it\'s the sweetest mystery\r\nWhen you\'re with me\r\nWe say a thousand words\r\nBut no one else is listening\r\nI will be', 0, 0, 0, '2017-01-01 00:01:01', '1234', '0:0:0:0:0:0:0:1', 0, 'https://ifh.cc/g/wbqzhy.jpg', 0, 2, 000),
	(18, '마크', 'like 1999', 'Woke up, it\'s 2021\r\nI wanna get texts, but I never wanna text back\r\nFuck man, I\'m 2020 done\r\nAnother paycheck and I blew it, but I\'m still sad\r\nWe talk all of the time\r\nBut it still feels like I\'m just a voice on the line, so\r\nIf you wanna come over, watch Friends and then get high\r\n', 0, 0, 0, '2021-11-27 01:25:23', '1234', '0:0:0:0:0:0:0:1', 3, 'https://ifh.cc/g/j4XePx.jpg', 0, 2, 000),
	(19, '만능열쇠', '아웃콜목골드캡슐', '목감기에 추천받아 샀는데 별로였어요.', 0, 0, 0, '2019-05-15 05:15:30', '1234', '0:0:0:0:0:0:0:1', 6, 'https://ifh.cc/g/jtYmpj.jpg', 0, 0, 002),
	(20, '밤비', '파워콜에스연질캡슐', '액상이라 더 효과가 빨리 도는 것 같아요. 심한 감기에는 소용없어요.', 0, 0, 0, '2019-05-15 05:15:30', '1234', '0:0:0:0:0:0:0:1', 8, 'https://ifh.cc/g/mYawHf.jpg', 0, 0, 003),
	(21, '불꽃카리스마', '아프니벤큐액', '브랜드: 코오롱제약, 성분: 디클로페낙 ', 0, 0, 0, '2021-11-27 01:25:23', '1234', '0:0:0:0:0:0:0:1', 1, 'https://ifh.cc/g/HVQstn.jpg', 0, 1, 000),
	(22, '삐에로', 'love again', '다시 한번 내게 말해줘\r\n다시 그날처럼 사랑한다고 해줘\r\n믿을 수 없었지 너의 모든 것에\r\nLike looking in the mirror 닮아 있던 우리\r\n사랑을 말해주던 그 예쁜 입술이\r\n꾹 잠궈진 듯 아무 말 없네\r\n난 이해가 안돼 마음으로는 왜\r\n날 사랑한다 해놓고 더 도망치려 해', 0, 0, 0, '2020-10-20 02:25:40', '1234', '0:0:0:0:0:0:0:1', 5, 'https://ifh.cc/g/vaRVNK.jpg', 0, 2, 000),
	(23, '샤이니', '스트렙실허니앤레몬트로키', '브랜드: Reckitt Benckiser Group plc, 성분: 플루르비프로펜', 0, 0, 0, '2019-05-15 05:15:30', '1234', '0:0:0:0:0:0:0:1', 2, 'https://ifh.cc/g/6uvKGb.jpg', 0, 1, 000),
	(24, '수호', 'inno Rheuma forte kr?m', '브랜드: NATURLAND, 성분: 로즈마리오일', 0, 0, 0, '2019-05-15 05:15:30', '1234', '0:0:0:0:0:0:0:1', 3, 'https://ifh.cc/g/5lBDk5.jpg', 0, 1, 000),
	(25, '시우민', '나비소녀', '조그만 날갯짓 널 향한 이끌림\r\n나에게 따라오라 손짓한 것 같아서\r\n애절한 눈빛과 무언의 이야기\r\n가슴에 회오리가 몰아치던 그날 밤\r\n오묘한 그대의 모습에 넋을 놓고\r\n하나뿐인 영혼을 뺏기고', 0, 0, 0, '2019-05-15 05:15:30', '1234', '0:0:0:0:0:0:0:1', 7, 'https://ifh.cc/g/gUZo5S.jpg', 0, 2, 000),
	(26, '지성', '마지막 첫사랑', '이건 사랑일지도 몰라\r\n이미 내 눈에는 너만 보여 난\r\n아직 아닐 거라 겁을 먹어도\r\n내게도 온 것 같아\r\n책에 적힌 글자들이 현실이 돼\r\n가슴이 곧 터져 버릴 것 같아\r\n아냐 어떤 말로도 설명할 수 없어\r\n그래 나에겐 너뿐이야', 0, 0, 0, '2020-10-20 02:25:40', '1234', '0:0:0:0:0:0:0:1', 3, 'https://ifh.cc/g/BAJSwO.jpg', 0, 2, 000),
	(27, '최최차차', '제일알지싹세티연질캡슐(세티리진염산염)', '비염 심할 때 먹고 있어요. ', 0, 0, 0, '2020-10-20 02:25:40', '1234', '0:0:0:0:0:0:0:1', 11, 'https://ifh.cc/g/5hIHmH.jpg', 0, 0, 004),
	(28, '태일', '심비코트터부헬러160/4.5μg', '브랜드: Symbicort, 성분: 부데소니드', 0, 0, 0, '2017-01-01 00:01:01', '1234', '0:0:0:0:0:0:0:1', 7, 'https://ifh.cc/g/oRyCfD.jpg', 0, 1, 000),
	(29, '유아', '확펜연질캡슐(나프록센)', '나프록센이 잘 안받아요. 급하게 샀는데 후회해요', 0, 0, 0, '2020-10-20 02:25:40', '1234', '0:0:0:0:0:0:0:1', 7, 'https://ifh.cc/g/sJmv4P.jpg', 0, 0, 001),
	(30, '이니스프리', '한신안티캄캡슐(은교산)', '브랜드: 한국신약, 성분: 감초, 금은화', 0, 0, 0, '2017-01-01 00:01:01', '1234', '0:0:0:0:0:0:0:1', 7, 'https://ifh.cc/g/pnqfp0.jpg', 0, 1, 000);
/*!40000 ALTER TABLE `tblboard` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
