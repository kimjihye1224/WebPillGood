-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        5.7.22-log - MySQL Community Server (GPL)
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- pillgood 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `pillgood` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pillgood`;

-- 테이블 pillgood.userinfo 구조 내보내기
CREATE TABLE IF NOT EXISTS `userinfo` (
  `user_Idx` int(11) NOT NULL AUTO_INCREMENT COMMENT '유저 구분 인덱스',
  `userId` varchar(45) NOT NULL COMMENT '아이디',
  `pw` varchar(45) DEFAULT NULL COMMENT '비밀번호',
  `name` varchar(45) DEFAULT NULL COMMENT '이름',
  `email` varchar(45) DEFAULT NULL COMMENT '이메일',
  `gender` tinyint(4) DEFAULT NULL COMMENT '성별',
  `nickname` varchar(45) DEFAULT NULL COMMENT '닉네임',
  `symptom` varchar(50) DEFAULT NULL COMMENT '증상',
  `userType` tinyint(4) NOT NULL DEFAULT '0' COMMENT '회원정보(일반/약사)',
  `birth` varchar(50) DEFAULT NULL COMMENT '생년월일',
  `img` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `nickname` (`nickname`),
  KEY `userType` (`userType`),
  KEY `user_Idx` (`user_Idx`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COMMENT='회원정보';

-- 테이블 데이터 pillgood.userinfo:~51 rows (대략적) 내보내기
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` (`user_Idx`, `userId`, `pw`, `name`, `email`, `gender`, `nickname`, `symptom`, `userType`, `birth`, `img`) VALUES
	(14, 'akzm', '1234', '이마크', 'wlrma@gmail.com', 0, '마크', '11000010101010000000', 0, '19980406', 'https://ifh.cc/g/Geo6iM.jpg'),
	(13, 'aldud', '1234', '황미영', 'dusfkrwntlrh@daum.net', 1, '티파니', '00000001100000000000', 0, '19980228', 'https://ifh.cc/g/RxQdcR.jpg'),
	(37, 'algus', '1234', '김미현', 'rhdqn@daum.net', 1, '미미', '00000001100000000000', 0, '19961120', 'https://ifh.cc/g/WfXygL.jpg'),
	(45, 'alsgh', '1234', '최민호', 'tkfkadl@daum.net', 0, '불꽃카리스마', '10110000110000000100', 0, '19951208', 'https://ifh.cc/g/kw9Qlu.jpg'),
	(32, 'alstjr', '1234', '김민석', 'rlagmlwh@daum.net', 0, '시우민', '00000110000001000000', 0, '19961111', 'https://ifh.cc/g/Tu1bCZ.jpg'),
	(19, 'alswjd', '1234', '김민정', 'gehye1224@naver.com', 1, '에스파는나야', '00010101000000111000', 1, '19980408', 'https://ifh.cc/g/YVxjxx.jpg'),
	(35, 'ckdals', '1234', '심창민', 'Rhrwha@gmail.com', 0, '최강창민', '00110000111100000000', 1, '19991105', 'https://ifh.cc/g/WIgNjw.jpg'),
	(5, 'dbfl', '1234', '권유리', 'gkftn@daum.net', 1, '소녀시대', '10100000000010001000', 1, '19991204', 'https://ifh.cc/g/gV1PYC.jpg'),
	(42, 'dbqls', '1234', '배유빈', 'elqlfmf@gmail.com', 1, '비니', '00010000000000000001', 0, '19950605', 'https://ifh.cc/g/pk4pY1.png'),
	(21, 'dbsdh', '1234', '정윤오', 'Rmxdlek@gmail.com', 0, '재현', '00000000000011010101', 0, '19970516', 'https://ifh.cc/g/yBuE6k.jpg'),
	(3, 'dbsdk', '1234', '임윤아', 'ek@gmail.com', 1, '이니스프리', '10000000001000000000', 0, '19990515', 'https://ifh.cc/g/3i5mCu.png'),
	(34, 'dmsdn', '1234', '차은우', 'wjdakffh@daum.net', 0, '최최차차', '11000000110000001000', 0, '19960609', 'https://ifh.cc/g/QFbU3y.jpg'),
	(44, 'dPdnjs', '1234', '최예원', 'rhkdus@daum.net', 1, '아린', '00001010101101110000', 0, '19950201', 'https://ifh.cc/g/UZg9qn.jpg'),
	(29, 'dPfla', '1234', '김예림', 'spro@naver.com', 1, '예리', '01010101000000100000', 0, '19970305', 'https://ifh.cc/g/vyPEcj.jpg'),
	(22, 'ehddud', '1234', '김동영', 'tlfgrh@daum.net', 0, '도영', '01010100011000000000', 0, '19970404', 'https://ifh.cc/g/KWnCkM.jpg'),
	(18, 'ehdgur', '1234', '이동혁', 'dlTekrn@daum.net', 0, '누구지', '00000000010000000100', 0, '19980110', 'https://ifh.cc/g/LTuCAV.jpg'),
	(15, 'gydus', '1234', '김효연', 'skadkTdj@naver.com', 1, '디저트', '00000000000000101100', 1, '19990704', 'https://ifh.cc/g/VkswY3.jpg'),
	(36, 'gywjd', '1234', '최효정', 'dksms@daum.net', 1, '캔디', '10101010000000110000', 0, '19961231', 'https://ifh.cc/g/KF9wCa.jpg'),
	(25, 'qorgus', '1234', '변백현', 'dlrpanjswl@daum.net', 0, '밤비', '11000000001000000000', 0, '19970214', 'https://ifh.cc/g/5G98lx.jpg'),
	(49, 'rbgus', '1234', '조규현', 'sorkdho@naver.com', 0, '삐에로', '00000000010000010000', 0, '19950717', 'https://ifh.cc/g/skzB9v.jpg'),
	(43, 'rlqja', '1234', '김기범', 'godi@naver.com', 0, '만능열쇠', '00000000001000000000', 0, '19950218', 'https://ifh.cc/g/BSwx5f.jpg'),
	(30, 'rudtn', '1234', '도경수', 'ahtwkrh@daum.net', 0, '디오', '00000000011100000001', 0, '19970227', 'https://ifh.cc/g/FlGIEw.jpg'),
	(12, 'tjdcks', '1234', '정성찬', 'rndrmagkek@gmail.com', 0, '엔시티', '10101010000000111000', 1, '19990102', 'https://ifh.cc/g/IRY2Fs.jpg'),
	(33, 'tldk', '1234', '유시아', 'djswp@naver.com', 1, '유아', '00011110000000000010', 0, '19960906', 'https://ifh.cc/g/qyZ1fj.jpg'),
	(24, 'tmddhks', '1234', '손승완', 'wjdakf@gmail.com', 1, '웬디', '10110000000000100000', 1, '19990502', 'https://ifh.cc/g/HvKktv.jpg'),
	(38, 'tmdgml', '1234', '현승희', 'ghkdwPsms@daum.net', 1, '쏘하이', '10001000010000100000', 0, '19960109', 'https://ifh.cc/g/kGg5pX.jpg'),
	(26, 'tmfrl', '1234', '강슬기', 'wlrk@gmail.com', 1, '슬기', '00000110000100000000', 0, '19970530', 'https://ifh.cc/g/xubfgV.jpg'),
	(50, 'tnaks', '1234', '이수만', 'dksgkfRk@gmail.com', 0, '선생님', '10000010001000001000', 1, '19990905', 'https://ifh.cc/g/JavrHM.jpg'),
	(20, 'tndud', '1234', '박수영', 'dho@naver.com', 1, '조이', '10101000111000000000', 0, '19981201', 'https://ifh.cc/g/iEKycM.jpg'),
	(7, 'tndus', '1234', '최수영', 'wlswk@gmail.com', 1, '런온', '11000000001110000000', 0, '19991001', 'https://ifh.cc/g/U7pK42.png'),
	(10, 'tnsrb', '1234', '이순규', 'gkrl@daum.net', 1, '써니', '00000000000000101011', 0, '19991223', 'https://ifh.cc/g/A9TrB6.jpg'),
	(31, 'tnwjd', '1234', '정수정', 'gkfdlfdmf@gmail.com', 1, '크리스탈', '10100000000000100000', 0, '19960508', 'https://ifh.cc/g/4Eq4xK.jpg'),
	(28, 'whddls', '1234', '김종인', 'dhtlqrosms@daum.net', 0, '카이', '00000000011100000100', 1, '19990808', 'https://ifh.cc/g/LbrmwN.jpg'),
	(6, 'wjddn', '1234', '김정우', 'tlfgek@gmail.com', 0, '정우', '00110101010000000000', 0, '19990701', 'https://ifh.cc/g/zjY3sS.jpg'),
	(17, 'wlals', '1234', '유지민', 'rndrmagkslRk@gmail.com', 1, '블랙맘바', '10000000000000000000', 0, '19981010', 'https://ifh.cc/g/owD3ZB.jpg'),
	(47, 'wldms', '1234', '이지은', 'skxkskfRk@gmail.com', 1, '블루밍', '10000000010010000000', 0, '19950207', 'https://ifh.cc/g/uPtxrr.jpg'),
	(48, 'wlehd', '1234', '이지동', 'codnsirh@daum.net', 1, '라일락', '00101010101100010000', 0, '19951204', 'https://ifh.cc/g/3TxJeh.jpg'),
	(41, 'wlgh', '1234', '김지호', 'dhk@gmail.com', 1, '영앤리치', '00000101010100100000', 1, '19990203', 'https://ifh.cc/g/xHQzI9.jpg'),
	(46, 'wlrma', '1234', '이지금', 'aksgrnsk@gmail.com', 1, '아이유', '00000110000000000001', 1, '19990402', 'https://ifh.cc/g/IgC8iF.png'),
	(39, 'wlsdn', '1234', '김진우', 'aksemfrh@daum.net', 0, '위너', '00000001000010000010', 0, '19960909', 'https://ifh.cc/g/zXn8Zj.jpg'),
	(11, 'wltjd', '1234', '박지성', 'rmfja@gmail.com', 0, '지성', '11100000011000000000', 0, '19980505', 'https://ifh.cc/g/9AqxFc.jpg'),
	(27, 'wngus', '1234', '배주현', 'RhrRhr@naver.com', 1, '아이린', '00111000000001100000', 0, '19970301', 'https://ifh.cc/g/qPcKY4.jpg'),
	(9, 'wnguss', '1234', '서주현', 'gehye@gmail.com', 1, '서현', '00000000000000001110', 0, '19991212', 'https://ifh.cc/g/yLqxZ4.jpg'),
	(23, 'wnsaus', '1234', '김준면', 'gksmsrjfRk@gmail.com', 0, '수호', '00000011000000011000', 0, '19970712', 'https://ifh.cc/g/81Dib0.jpg'),
	(8, 'woals', '1234', '나재민', 'woals@naver.com', 1, '재민', '00111000101010000000', 0, '19991128', 'https://ifh.cc/g/pPVep1.jpg'),
	(1, 'wsph', '1234', '이제노', 'wpsh@navercom', 1, '제노', '00000000000000001000', 0, '19991211', 'P8.png'),
	(40, 'xoals', '1234', '이태민', 'rhkwpgkrl@daum.net', 0, '샤이니', '10110000000100001000', 0, '19960519', 'https://ifh.cc/g/j9NJyp.jpg'),
	(16, 'xodlf', '1234', '문태일', 'dlqslek@gmail.com', 0, '태일', '00000000000000000001', 0, '19980220', 'https://ifh.cc/g/dBPsEc.png'),
	(4, 'xodus', '1234', '김태연', 'rndrmago@naver.com', 1, '메인보컬', '11100000000000000000', 0, '19991130', 'https://ifh.cc/g/BzHGxX.jpg'),
	(2, 'xodyd', '1234', '이태용', 'xodyd@nate.com', 1, '리더', '00000010101011100000', 0, '19990107', 'https://ifh.cc/g/iEXDGS.jpg');
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
