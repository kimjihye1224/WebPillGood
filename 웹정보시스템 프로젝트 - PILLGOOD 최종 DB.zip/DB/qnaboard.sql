-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        5.7.22-log - MySQL Community Server (GPL)
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- pillgood 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `pillgood` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pillgood`;

-- 테이블 pillgood.qnaboard 구조 내보내기
CREATE TABLE IF NOT EXISTS `qnaboard` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `content` text,
  `pos` smallint(7) unsigned DEFAULT NULL,
  `ref` smallint(7) DEFAULT NULL,
  `depth` smallint(7) unsigned DEFAULT NULL,
  `regdate` varchar(20) DEFAULT NULL,
  `pass` varchar(15) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `count` smallint(7) unsigned DEFAULT NULL,
  `filename` varchar(30) DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `FK_qnaboard_userinfo` (`nickname`),
  CONSTRAINT `FK_qnaboard_userinfo` FOREIGN KEY (`nickname`) REFERENCES `userinfo` (`nickname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- 테이블 데이터 pillgood.qnaboard:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `qnaboard` DISABLE KEYS */;
INSERT INTO `qnaboard` (`num`, `nickname`, `subject`, `content`, `pos`, `ref`, `depth`, `regdate`, `pass`, `ip`, `count`, `filename`, `filesize`) VALUES
	(17, '제노', '짱!', '나는 역시 늘 짱!', 0, 1, 0, '2021-12-03 15:11:19', '1', '0:0:0:0:0:0:0:1', 14, NULL, 0),
	(18, '소녀시대', 're:짱!', '      	나는 역시 늘 짱!\r\n      	========답변 글을 쓰세요.=======\r\n      	ㄴㄴ 내가 더 짱', 2, 1, 1, '2021-12-03 15:11:39', '1', '0:0:0:0:0:0:0:1', 6, NULL, NULL);
/*!40000 ALTER TABLE `qnaboard` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
