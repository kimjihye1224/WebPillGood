-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        5.7.22-log - MySQL Community Server (GPL)
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- pillgood 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `pillgood` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pillgood`;

-- 테이블 pillgood.pharmacistinfo 구조 내보내기
CREATE TABLE IF NOT EXISTS `pharmacistinfo` (
  `userId` varchar(50) NOT NULL,
  `career` int(11) DEFAULT NULL,
  `pcode` int(15) NOT NULL,
  PRIMARY KEY (`userId`),
  KEY `FK_pharmacistinfo_pauthentication` (`pcode`),
  CONSTRAINT `FK_pharmacistinfo_pauthentication` FOREIGN KEY (`pcode`) REFERENCES `pauthentication` (`pcode`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_pharmacistinfo_userinfo` FOREIGN KEY (`userId`) REFERENCES `userinfo` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 pillgood.pharmacistinfo:~10 rows (대략적) 내보내기
/*!40000 ALTER TABLE `pharmacistinfo` DISABLE KEYS */;
INSERT INTO `pharmacistinfo` (`userId`, `career`, `pcode`) VALUES
	('alswjd', 5, 1123),
	('ckdals', 5, 1105),
	('dbfl', 4, 1124),
	('gydus', 3, 1074),
	('tjdcks', 2, 1012),
	('tmddhks', 1, 1052),
	('tnaks', 2, 1095),
	('whddls', 3, 1088),
	('wlgh', 1, 1023),
	('wlrma', 3, 1042);
/*!40000 ALTER TABLE `pharmacistinfo` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
